﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Calculation_With_Radio_Button
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rdoDivision = New System.Windows.Forms.RadioButton()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.txtNumber2 = New System.Windows.Forms.TextBox()
        Me.txtNumber1 = New System.Windows.Forms.TextBox()
        Me.rdoMultiplication = New System.Windows.Forms.RadioButton()
        Me.rdoSubtraction = New System.Windows.Forms.RadioButton()
        Me.rdoAddition = New System.Windows.Forms.RadioButton()
        Me.lblR = New System.Windows.Forms.Label()
        Me.lblNum2 = New System.Windows.Forms.Label()
        Me.lblNum1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'rdoDivision
        '
        Me.rdoDivision.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.rdoDivision.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoDivision.Location = New System.Drawing.Point(292, 129)
        Me.rdoDivision.Name = "rdoDivision"
        Me.rdoDivision.Size = New System.Drawing.Size(104, 24)
        Me.rdoDivision.TabIndex = 32
        Me.rdoDivision.TabStop = True
        Me.rdoDivision.Text = "Division"
        Me.rdoDivision.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(37, 159)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(359, 28)
        Me.btnClose.TabIndex = 31
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'txtResult
        '
        Me.txtResult.Location = New System.Drawing.Point(128, 90)
        Me.txtResult.Name = "txtResult"
        Me.txtResult.Size = New System.Drawing.Size(100, 20)
        Me.txtResult.TabIndex = 30
        '
        'txtNumber2
        '
        Me.txtNumber2.Location = New System.Drawing.Point(128, 50)
        Me.txtNumber2.Name = "txtNumber2"
        Me.txtNumber2.Size = New System.Drawing.Size(100, 20)
        Me.txtNumber2.TabIndex = 29
        '
        'txtNumber1
        '
        Me.txtNumber1.Location = New System.Drawing.Point(128, 11)
        Me.txtNumber1.Name = "txtNumber1"
        Me.txtNumber1.Size = New System.Drawing.Size(100, 20)
        Me.txtNumber1.TabIndex = 28
        '
        'rdoMultiplication
        '
        Me.rdoMultiplication.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.rdoMultiplication.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoMultiplication.Location = New System.Drawing.Point(292, 88)
        Me.rdoMultiplication.Name = "rdoMultiplication"
        Me.rdoMultiplication.Size = New System.Drawing.Size(104, 24)
        Me.rdoMultiplication.TabIndex = 27
        Me.rdoMultiplication.TabStop = True
        Me.rdoMultiplication.Text = "Multiplication"
        Me.rdoMultiplication.UseVisualStyleBackColor = True
        '
        'rdoSubtraction
        '
        Me.rdoSubtraction.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.rdoSubtraction.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoSubtraction.Location = New System.Drawing.Point(292, 47)
        Me.rdoSubtraction.Name = "rdoSubtraction"
        Me.rdoSubtraction.Size = New System.Drawing.Size(104, 24)
        Me.rdoSubtraction.TabIndex = 26
        Me.rdoSubtraction.TabStop = True
        Me.rdoSubtraction.Text = "Substraction"
        Me.rdoSubtraction.UseVisualStyleBackColor = True
        '
        'rdoAddition
        '
        Me.rdoAddition.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.rdoAddition.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdoAddition.Location = New System.Drawing.Point(292, 8)
        Me.rdoAddition.Name = "rdoAddition"
        Me.rdoAddition.Size = New System.Drawing.Size(104, 24)
        Me.rdoAddition.TabIndex = 25
        Me.rdoAddition.TabStop = True
        Me.rdoAddition.Text = "Addition"
        Me.rdoAddition.UseVisualStyleBackColor = True
        '
        'lblR
        '
        Me.lblR.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblR.Location = New System.Drawing.Point(12, 88)
        Me.lblR.Name = "lblR"
        Me.lblR.Size = New System.Drawing.Size(100, 23)
        Me.lblR.TabIndex = 24
        Me.lblR.Text = "Results"
        Me.lblR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNum2
        '
        Me.lblNum2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNum2.Location = New System.Drawing.Point(12, 48)
        Me.lblNum2.Name = "lblNum2"
        Me.lblNum2.Size = New System.Drawing.Size(100, 23)
        Me.lblNum2.TabIndex = 23
        Me.lblNum2.Text = "Number 2:"
        Me.lblNum2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNum1
        '
        Me.lblNum1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNum1.Location = New System.Drawing.Point(12, 9)
        Me.lblNum1.Name = "lblNum1"
        Me.lblNum1.Size = New System.Drawing.Size(100, 23)
        Me.lblNum1.TabIndex = 22
        Me.lblNum1.Text = "Number 1:"
        Me.lblNum1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Calculation_With_Radio_Button
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(426, 201)
        Me.Controls.Add(Me.rdoDivision)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.txtNumber2)
        Me.Controls.Add(Me.txtNumber1)
        Me.Controls.Add(Me.rdoMultiplication)
        Me.Controls.Add(Me.rdoSubtraction)
        Me.Controls.Add(Me.rdoAddition)
        Me.Controls.Add(Me.lblR)
        Me.Controls.Add(Me.lblNum2)
        Me.Controls.Add(Me.lblNum1)
        Me.Name = "Calculation_With_Radio_Button"
        Me.Text = "Calculation_With_Radio_Button"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents rdoDivision As System.Windows.Forms.RadioButton
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents txtResult As System.Windows.Forms.TextBox
    Friend WithEvents txtNumber2 As System.Windows.Forms.TextBox
    Friend WithEvents txtNumber1 As System.Windows.Forms.TextBox
    Friend WithEvents rdoMultiplication As System.Windows.Forms.RadioButton
    Friend WithEvents rdoSubtraction As System.Windows.Forms.RadioButton
    Friend WithEvents rdoAddition As System.Windows.Forms.RadioButton
    Friend WithEvents lblR As System.Windows.Forms.Label
    Friend WithEvents lblNum2 As System.Windows.Forms.Label
    Friend WithEvents lblNum1 As System.Windows.Forms.Label
End Class
