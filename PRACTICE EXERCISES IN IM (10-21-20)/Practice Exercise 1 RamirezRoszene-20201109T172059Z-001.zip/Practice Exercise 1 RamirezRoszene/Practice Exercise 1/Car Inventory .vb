﻿Public Class Car_Inventory

    Inherits System.Windows.Forms.Form
    Dim Car(10) As ListOfCars
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Car(0) = New ListOfCars
        Car(0).Make = "Honda"
        Car(0).Model = "Civic"
        Car(0).CarYear = 1998
        Car(0).Doors = 4
        Car(0).CarPicture = "Civic1.bmp"

        Car(1) = New ListOfCars
        Car(1).Make = "Hyundai"
        Car(1).Model = "Elantra"
        Car(1).CarYear = 1996
        Car(1).Doors = 4
        Car(1).CarPicture = "Elantra.bmp"

        Car(2) = New ListOfCars
        Car(2).Make = "Ford"
        Car(2).Model = "Escape"
        Car(2).CarYear = 2003
        Car(2).Doors = 5
        Car(2).CarPicture = "FordEscape1.bmp"

        Car(3) = New ListOfCars
        Car(3).Make = "Ford"
        Car(3).Model = "Escort"
        Car(3).CarYear = 1997
        Car(3).Doors = 2
        Car(3).CarPicture = "FordEscort1.bmp"

        Car(4) = New ListOfCars
        Car(4).Make = "Mercury"
        Car(4).Model = "Grand Marquis"
        Car(4).CarYear = 2001
        Car(4).Doors = 4
        Car(4).CarPicture = "GrandMarquis.bmp"

        Car(5) = New ListOfCars
        Car(5).Make = "Mercury"
        Car(5).Model = "Mystique"
        Car(5).CarYear = 2000
        Car(5).Doors = 4
        Car(5).CarPicture = "Mystique.bmp"

        Car(6) = New ListOfCars
        Car(6).Make = "Lincoln"
        Car(6).Model = "Navigator"
        Car(6).CarYear = 2003
        Car(6).Doors = 5
        Car(6).CarPicture = "Navigator1.bmp"

        Car(7) = New ListOfCars
        Car(7).Make = "Nissan"
        Car(7).Model = "Sentra"
        Car(7).CarYear = 1997
        Car(7).Doors = 2
        Car(7).CarPicture = "Sentra.bmp"

        Car(8) = New ListOfCars
        Car(8).Make = "Ford"
        Car(8).Model = "Focus"
        Car(8).CarYear = 2002
        Car(8).Doors = 4
        Car(8).CarPicture = "Focus.bmp"

        Car(9) = New ListOfCars
        Car(9).Make = "Ki"
        Car(9).Model = "Sephia"
        Car(9).CarYear = 2003
        Car(9).Doors = 4
        Car(9).CarPicture = "Sephia.bmp"


    End Sub
    Private Sub trbSlider_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trbSlider.Scroll
        ' Get the index of the current value of the track bar - 1
        Dim CurPos As Int16 = trbSlider.Value
        ' Based on the current index, retrieve the values of the
        ' current car and assign each to the corresponding control
        ' txtMake.Text = Car(CurPos).Make
        txtMake.Text = Car(CurPos).Make
        txtModel.Text = Car(CurPos).Model
        TxtYear.Text = Car(CurPos).CarYear.ToString()
        TxtDoors.Text = Car(CurPos).Doors.ToString()
        pctCarPicture.Image = Drawing.Image.FromFile(Car(CurPos).CarPicture)
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Close()
    End Sub
End Class