﻿Public Class Color_Changer

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Close()
    End Sub
    Private Sub VScrollBar4_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs)

    End Sub

    Private Sub VScrollBar1_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles scrGreen.Scroll
        Dim RedValue As Integer
        Dim GreenValue As Integer
        Dim BlueValue As Integer
        RedValue = scrRed.Value
        GreenValue = scrGreen.Value
        BlueValue = scrBlue.Value
        pnlPreview.BackColor = System.Drawing.Color.FromArgb(RedValue, GreenValue, BlueValue)
    End Sub

    Private Sub scrRed_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles scrRed.Scroll
        Dim RedValue As Integer
        Dim GreenValue As Integer
        Dim BlueValue As Integer
        RedValue = scrRed.Value
        GreenValue = scrGreen.Value
        BlueValue = scrBlue.Value
        pnlPreview.BackColor = System.Drawing.Color.FromArgb(RedValue, GreenValue,
        BlueValue)
    End Sub

    Private Sub scrBlue_Scroll(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ScrollEventArgs) Handles scrBlue.Scroll
        Dim RedValue As Integer
        Dim GreenValue As Integer
        Dim BlueValue As Integer
        RedValue = scrRed.Value
        GreenValue = scrGreen.Value
        BlueValue = scrBlue.Value
        pnlPreview.BackColor = System.Drawing.Color.FromArgb(RedValue, GreenValue,
        BlueValue)
    End Sub
End Class