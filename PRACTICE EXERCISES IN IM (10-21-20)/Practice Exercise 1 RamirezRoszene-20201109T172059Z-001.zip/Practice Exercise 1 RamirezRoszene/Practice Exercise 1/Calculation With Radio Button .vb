﻿Public Class Calculation_With_Radio_Button

    Private Sub rdoA_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdoAddition.CheckedChanged
        Dim Number1, Number2, Result As Double
        If txtNumber1.Text = "" Then
            Number1 = 0
        Else
            Number1 = Convert.ToDouble(txtNumber1.Text)
        End If
        If txtNumber2.Text = "" Then
            Number2 = 0
        Else
            Number2 = Convert.ToDouble(txtNumber2.Text)
        End If
        Result = Number1 + Number2
        txtResult.Text = Result.ToString()
    End Sub



    Private Sub rdoS_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdoSubtraction.CheckedChanged
        Dim Number1, Number2, Result As Double
        If txtNumber1.Text = "" Then
            Number1 = 0
        Else
            Number1 = Convert.ToDouble(txtNumber1.Text)
        End If
        If txtNumber2.Text = "" Then
            Number2 = 0
        Else
            Number2 = Convert.ToDouble(txtNumber2.Text)
        End If

        Result = Number1 - Number2
        txtResult.Text = Result.ToString()

    End Sub


    Private Sub rdoMultiplication_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdoMultiplication.CheckedChanged
        Dim Number1, Number2, Result As Double
        If txtNumber1.Text = "" Then
            Number1 = 0
        Else
            Number1 = Convert.ToDouble(txtNumber1.Text)
        End If

        If txtNumber2.Text = "" Then
            Number2 = 0
        Else
            Number2 = Convert.ToDouble(txtNumber2.Text)
        End If
        Result = Number1 * Number2
        txtResult.Text = Result.ToString()
    End Sub

    Private Sub rdoDivision_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdoDivision.CheckedChanged
        Dim Number1, Number2, Result As Double
        If txtNumber1.Text = "" Then
            Number1 = 0
        Else
            Number1 = Convert.ToDouble(txtNumber1.Text)
        End If
        If txtNumber2.Text = "" Then
            Number2 = 0
        Else
            Number2 = Convert.ToDouble(txtNumber2.Text)
        End If
        Result = Number1 / Number2
        txtResult.Text = Result.ToString()
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Close()
    End Sub
End Class