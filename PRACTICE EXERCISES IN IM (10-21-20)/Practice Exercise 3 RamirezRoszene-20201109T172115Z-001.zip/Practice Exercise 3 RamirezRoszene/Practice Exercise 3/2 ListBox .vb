﻿Public Class _2_ListBox

    Private Sub lst1_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lst1.DoubleClick
        Dim i As Byte
        For i = 0 To lst1.Items.Count
            If lst1.SelectedIndex = i Then
                lst2.Items.Add(lst1.SelectedItem)
            End If
        Next
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Dim i As Integer
        For i = 0 To lst2.Items.Count
            If lst2.SelectedIndex = i Then
                lst2.Items.RemoveAt(i)
            End If
        Next i
    End Sub
    Private Sub btnClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAll.Click
        lst1.ClearSelected()
        lst2.Items.Clear()
    End Sub
End Class