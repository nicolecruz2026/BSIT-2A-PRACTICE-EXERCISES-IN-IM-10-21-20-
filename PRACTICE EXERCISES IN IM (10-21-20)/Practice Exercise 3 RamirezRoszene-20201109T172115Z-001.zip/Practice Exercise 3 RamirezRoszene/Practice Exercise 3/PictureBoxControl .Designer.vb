﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PictureBoxControl
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDisable = New System.Windows.Forms.Button()
        Me.btnHide = New System.Windows.Forms.Button()
        Me.btnEnable = New System.Windows.Forms.Button()
        Me.btnShow = New System.Windows.Forms.Button()
        Me.picBaby = New System.Windows.Forms.PictureBox()
        CType(Me.picBaby, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnDisable
        '
        Me.btnDisable.Location = New System.Drawing.Point(286, 327)
        Me.btnDisable.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDisable.Name = "btnDisable"
        Me.btnDisable.Size = New System.Drawing.Size(172, 50)
        Me.btnDisable.TabIndex = 19
        Me.btnDisable.Text = "Disable"
        Me.btnDisable.UseVisualStyleBackColor = True
        '
        'btnHide
        '
        Me.btnHide.Location = New System.Drawing.Point(286, 238)
        Me.btnHide.Margin = New System.Windows.Forms.Padding(4)
        Me.btnHide.Name = "btnHide"
        Me.btnHide.Size = New System.Drawing.Size(172, 50)
        Me.btnHide.TabIndex = 18
        Me.btnHide.Text = "Hide"
        Me.btnHide.UseVisualStyleBackColor = True
        '
        'btnEnable
        '
        Me.btnEnable.Location = New System.Drawing.Point(13, 327)
        Me.btnEnable.Margin = New System.Windows.Forms.Padding(4)
        Me.btnEnable.Name = "btnEnable"
        Me.btnEnable.Size = New System.Drawing.Size(172, 50)
        Me.btnEnable.TabIndex = 17
        Me.btnEnable.Text = "Enable"
        Me.btnEnable.UseVisualStyleBackColor = True
        '
        'btnShow
        '
        Me.btnShow.Location = New System.Drawing.Point(13, 238)
        Me.btnShow.Margin = New System.Windows.Forms.Padding(4)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(172, 50)
        Me.btnShow.TabIndex = 16
        Me.btnShow.Text = "Show"
        Me.btnShow.UseVisualStyleBackColor = True
        '
        'picBaby
        '
        Me.picBaby.Location = New System.Drawing.Point(101, 17)
        Me.picBaby.Margin = New System.Windows.Forms.Padding(4)
        Me.picBaby.Name = "picBaby"
        Me.picBaby.Size = New System.Drawing.Size(261, 196)
        Me.picBaby.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBaby.TabIndex = 15
        Me.picBaby.TabStop = False
        '
        'PictureBoxControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(480, 408)
        Me.Controls.Add(Me.btnDisable)
        Me.Controls.Add(Me.btnHide)
        Me.Controls.Add(Me.btnEnable)
        Me.Controls.Add(Me.btnShow)
        Me.Controls.Add(Me.picBaby)
        Me.Name = "PictureBoxControl"
        Me.Text = "PictureBoxControl"
        CType(Me.picBaby, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnDisable As System.Windows.Forms.Button
    Friend WithEvents btnHide As System.Windows.Forms.Button
    Friend WithEvents btnEnable As System.Windows.Forms.Button
    Friend WithEvents btnShow As System.Windows.Forms.Button
    Friend WithEvents picBaby As System.Windows.Forms.PictureBox
End Class
