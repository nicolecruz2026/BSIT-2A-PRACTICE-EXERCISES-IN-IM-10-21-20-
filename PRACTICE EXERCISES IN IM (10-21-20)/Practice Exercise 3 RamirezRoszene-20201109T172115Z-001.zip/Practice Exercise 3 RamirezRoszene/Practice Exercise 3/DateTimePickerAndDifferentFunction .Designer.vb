﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DateTimePickerAndDifferentFunction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtpOut = New System.Windows.Forms.DateTimePicker()
        Me.lblTotDays = New System.Windows.Forms.Label()
        Me.btnCompute2 = New System.Windows.Forms.Button()
        Me.txtOut = New System.Windows.Forms.TextBox()
        Me.txtIn = New System.Windows.Forms.TextBox()
        Me.btnOut = New System.Windows.Forms.Button()
        Me.dtpIn = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCompute1 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnIn = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dtpOut
        '
        Me.dtpOut.CalendarFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpOut.Location = New System.Drawing.Point(19, 78)
        Me.dtpOut.Name = "dtpOut"
        Me.dtpOut.Size = New System.Drawing.Size(200, 22)
        Me.dtpOut.TabIndex = 1
        '
        'lblTotDays
        '
        Me.lblTotDays.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblTotDays.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotDays.Location = New System.Drawing.Point(218, 177)
        Me.lblTotDays.Name = "lblTotDays"
        Me.lblTotDays.Size = New System.Drawing.Size(91, 49)
        Me.lblTotDays.TabIndex = 34
        Me.lblTotDays.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnCompute2
        '
        Me.btnCompute2.Location = New System.Drawing.Point(354, 177)
        Me.btnCompute2.Name = "btnCompute2"
        Me.btnCompute2.Size = New System.Drawing.Size(155, 49)
        Me.btnCompute2.TabIndex = 35
        Me.btnCompute2.Text = "Compute2"
        Me.btnCompute2.UseVisualStyleBackColor = True
        '
        'txtOut
        '
        Me.txtOut.Location = New System.Drawing.Point(164, 94)
        Me.txtOut.Name = "txtOut"
        Me.txtOut.Size = New System.Drawing.Size(108, 20)
        Me.txtOut.TabIndex = 30
        '
        'txtIn
        '
        Me.txtIn.Location = New System.Drawing.Point(164, 27)
        Me.txtIn.Name = "txtIn"
        Me.txtIn.Size = New System.Drawing.Size(108, 20)
        Me.txtIn.TabIndex = 29
        '
        'btnOut
        '
        Me.btnOut.Location = New System.Drawing.Point(12, 78)
        Me.btnOut.Name = "btnOut"
        Me.btnOut.Size = New System.Drawing.Size(133, 51)
        Me.btnOut.TabIndex = 28
        Me.btnOut.Text = "Check Out"
        Me.btnOut.UseVisualStyleBackColor = True
        '
        'dtpIn
        '
        Me.dtpIn.Location = New System.Drawing.Point(19, 34)
        Me.dtpIn.Name = "dtpIn"
        Me.dtpIn.Size = New System.Drawing.Size(200, 22)
        Me.dtpIn.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(225, 150)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Total Days"
        '
        'btnCompute1
        '
        Me.btnCompute1.Location = New System.Drawing.Point(12, 177)
        Me.btnCompute1.Name = "btnCompute1"
        Me.btnCompute1.Size = New System.Drawing.Size(152, 49)
        Me.btnCompute1.TabIndex = 32
        Me.btnCompute1.Text = "Compute1"
        Me.btnCompute1.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtpOut)
        Me.GroupBox1.Controls.Add(Me.dtpIn)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(302, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(235, 117)
        Me.GroupBox1.TabIndex = 31
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "DateTimePicker"
        '
        'btnIn
        '
        Me.btnIn.Location = New System.Drawing.Point(12, 12)
        Me.btnIn.Name = "btnIn"
        Me.btnIn.Size = New System.Drawing.Size(133, 49)
        Me.btnIn.TabIndex = 27
        Me.btnIn.Text = "Check In"
        Me.btnIn.UseVisualStyleBackColor = True
        '
        'DateTimePickerAndDifferentFunction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(549, 243)
        Me.Controls.Add(Me.lblTotDays)
        Me.Controls.Add(Me.btnCompute2)
        Me.Controls.Add(Me.txtOut)
        Me.Controls.Add(Me.txtIn)
        Me.Controls.Add(Me.btnOut)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnCompute1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnIn)
        Me.Name = "DateTimePickerAndDifferentFunction"
        Me.Text = "DateTimePickerAndDifferentFunction"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dtpOut As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblTotDays As System.Windows.Forms.Label
    Friend WithEvents btnCompute2 As System.Windows.Forms.Button
    Friend WithEvents txtOut As System.Windows.Forms.TextBox
    Friend WithEvents txtIn As System.Windows.Forms.TextBox
    Friend WithEvents btnOut As System.Windows.Forms.Button
    Friend WithEvents dtpIn As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnCompute1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btnIn As System.Windows.Forms.Button
End Class
