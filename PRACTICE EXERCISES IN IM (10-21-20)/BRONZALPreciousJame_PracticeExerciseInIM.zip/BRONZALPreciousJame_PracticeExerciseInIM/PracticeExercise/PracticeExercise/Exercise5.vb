﻿Public Class Exercise5

    Private Sub lst1_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lst1.DoubleClick

        If lst1.SelectedIndex = 0 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If
        If lst1.SelectedIndex = 1 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If
        If lst1.SelectedIndex = 2 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If
        If lst1.SelectedIndex = 3 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        lst2.Items.Clear()
    End Sub

    Private Sub btnCLearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCLearAll.Click
        lst1.ClearSelected()
        lst2.Items.Clear()
    End Sub
End Class