﻿Public Class Exercise1

    Private Sub btnTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest.Click
        Dim GenRnd As New Random
        Dim GuessNum, GenRndNum As Integer

        Try
            GuessNum = CInt(txtNumber.Text)
            GenRndNum = GenRnd.Next(1, 10)

            If GuessNum = GenRndNum Then
                MessageBox.Show("That's correct!", "Guessing Game", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("That's Wrong" + vbNewLine + "The correct answer is: " + CStr(GenRndNum), "Guessing Game", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch MyError As InvalidCastException
            MessageBox.Show("Please enter a number...", "Guessing Game")


        End Try

        txtNumber.Text = ""
        txtNumber.Focus()
    End Sub
End Class
