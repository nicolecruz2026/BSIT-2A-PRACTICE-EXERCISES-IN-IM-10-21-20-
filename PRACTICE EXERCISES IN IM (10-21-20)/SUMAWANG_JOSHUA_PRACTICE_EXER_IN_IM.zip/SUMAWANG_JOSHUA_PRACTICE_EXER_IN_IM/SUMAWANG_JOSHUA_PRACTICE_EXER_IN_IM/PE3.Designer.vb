﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PE3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCompute = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lstParts = New System.Windows.Forms.ListBox()
        Me.cboDisc = New System.Windows.Forms.ComboBox()
        Me.nudQuan = New System.Windows.Forms.NumericUpDown()
        Me.lblUPrice = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblSubTot = New System.Windows.Forms.Label()
        Me.lblDisc = New System.Windows.Forms.Label()
        Me.lblTotAmt = New System.Windows.Forms.Label()
        CType(Me.nudQuan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnCompute
        '
        Me.btnCompute.Location = New System.Drawing.Point(63, 216)
        Me.btnCompute.Name = "btnCompute"
        Me.btnCompute.Size = New System.Drawing.Size(106, 33)
        Me.btnCompute.TabIndex = 0
        Me.btnCompute.Text = "Compute"
        Me.btnCompute.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(166, 216)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 33)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(237, 216)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(95, 33)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lstParts
        '
        Me.lstParts.FormattingEnabled = True
        Me.lstParts.Items.AddRange(New Object() {"Monitor", "Keyboard ", "Mouse", "Hard Drive", "Disk Drive"})
        Me.lstParts.Location = New System.Drawing.Point(38, 12)
        Me.lstParts.Name = "lstParts"
        Me.lstParts.Size = New System.Drawing.Size(120, 95)
        Me.lstParts.TabIndex = 3
        '
        'cboDisc
        '
        Me.cboDisc.FormattingEnabled = True
        Me.cboDisc.Items.AddRange(New Object() {"5%", "10%", "15%", "No Discount"})
        Me.cboDisc.Location = New System.Drawing.Point(38, 145)
        Me.cboDisc.Name = "cboDisc"
        Me.cboDisc.Size = New System.Drawing.Size(121, 21)
        Me.cboDisc.TabIndex = 4
        '
        'nudQuan
        '
        Me.nudQuan.Location = New System.Drawing.Point(270, 33)
        Me.nudQuan.Name = "nudQuan"
        Me.nudQuan.Size = New System.Drawing.Size(49, 20)
        Me.nudQuan.TabIndex = 5
        '
        'lblUPrice
        '
        Me.lblUPrice.AutoSize = True
        Me.lblUPrice.Location = New System.Drawing.Point(188, 12)
        Me.lblUPrice.Name = "lblUPrice"
        Me.lblUPrice.Size = New System.Drawing.Size(53, 13)
        Me.lblUPrice.TabIndex = 6
        Me.lblUPrice.Text = "Unit Price"
        Me.lblUPrice.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(188, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Quantity"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSubTot
        '
        Me.lblSubTot.AutoSize = True
        Me.lblSubTot.Location = New System.Drawing.Point(188, 67)
        Me.lblSubTot.Name = "lblSubTot"
        Me.lblSubTot.Size = New System.Drawing.Size(53, 13)
        Me.lblSubTot.TabIndex = 8
        Me.lblSubTot.Text = "Sub-Total"
        Me.lblSubTot.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDisc
        '
        Me.lblDisc.AutoSize = True
        Me.lblDisc.Location = New System.Drawing.Point(188, 111)
        Me.lblDisc.Name = "lblDisc"
        Me.lblDisc.Size = New System.Drawing.Size(49, 13)
        Me.lblDisc.TabIndex = 9
        Me.lblDisc.Text = "Discount"
        Me.lblDisc.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblTotAmt
        '
        Me.lblTotAmt.AutoSize = True
        Me.lblTotAmt.Location = New System.Drawing.Point(188, 153)
        Me.lblTotAmt.Name = "lblTotAmt"
        Me.lblTotAmt.Size = New System.Drawing.Size(70, 13)
        Me.lblTotAmt.TabIndex = 10
        Me.lblTotAmt.Text = "Total Amount"
        Me.lblTotAmt.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'PE3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(363, 261)
        Me.Controls.Add(Me.lblTotAmt)
        Me.Controls.Add(Me.lblDisc)
        Me.Controls.Add(Me.lblSubTot)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblUPrice)
        Me.Controls.Add(Me.nudQuan)
        Me.Controls.Add(Me.cboDisc)
        Me.Controls.Add(Me.lstParts)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCompute)
        Me.Name = "PE3"
        Me.Text = "ComboBox,ListBox & NumberUpDown"
        CType(Me.nudQuan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCompute As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents lstParts As System.Windows.Forms.ListBox
    Friend WithEvents cboDisc As System.Windows.Forms.ComboBox
    Friend WithEvents nudQuan As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblUPrice As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblSubTot As System.Windows.Forms.Label
    Friend WithEvents lblDisc As System.Windows.Forms.Label
    Friend WithEvents lblTotAmt As System.Windows.Forms.Label
End Class
