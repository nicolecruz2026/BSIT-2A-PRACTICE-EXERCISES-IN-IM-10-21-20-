﻿Public Class PE2

    Private Sub btnSpin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSpin.Click
        Dim rndGen As New Random
        Dim n1, n2, n3 As Integer


        n1 = rndGen.Next(1, 10)
        n2 = rndGen.Next(1, 10)
        n3 = rndGen.Next(1, 10)

        lblNum1.Text = n1
        lblNum2.Text = n2
        lblNum3.Text = n3



        If n1 = 7 Or n2 = 7 OrElse n3 = 7 Then
            MessageBox.Show("Congratulation!! You win", "Lucky Seven")
        Else
            MessageBox.Show("Sorry You Lose..", "Lucky Seven")
        End If

    End Sub
End Class