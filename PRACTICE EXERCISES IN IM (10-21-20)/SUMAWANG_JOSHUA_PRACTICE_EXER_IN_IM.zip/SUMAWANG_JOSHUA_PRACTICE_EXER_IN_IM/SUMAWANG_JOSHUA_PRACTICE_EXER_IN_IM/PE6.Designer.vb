﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PE6
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnIn = New System.Windows.Forms.Button()
        Me.btnOut = New System.Windows.Forms.Button()
        Me.btnCompute1 = New System.Windows.Forms.Button()
        Me.dtpIn = New System.Windows.Forms.DateTimePicker()
        Me.lblTotDays = New System.Windows.Forms.Label()
        Me.txtIn = New System.Windows.Forms.TextBox()
        Me.txtOut = New System.Windows.Forms.TextBox()
        Me.btnCompute2 = New System.Windows.Forms.Button()
        Me.dtOut = New System.Windows.Forms.DateTimePicker()
        Me.SuspendLayout()
        '
        'btnIn
        '
        Me.btnIn.Location = New System.Drawing.Point(12, 56)
        Me.btnIn.Name = "btnIn"
        Me.btnIn.Size = New System.Drawing.Size(75, 23)
        Me.btnIn.TabIndex = 0
        Me.btnIn.Text = "Check In"
        Me.btnIn.UseVisualStyleBackColor = True
        '
        'btnOut
        '
        Me.btnOut.Location = New System.Drawing.Point(12, 85)
        Me.btnOut.Name = "btnOut"
        Me.btnOut.Size = New System.Drawing.Size(75, 23)
        Me.btnOut.TabIndex = 1
        Me.btnOut.Text = "Check Out"
        Me.btnOut.UseVisualStyleBackColor = True
        '
        'btnCompute1
        '
        Me.btnCompute1.Location = New System.Drawing.Point(70, 157)
        Me.btnCompute1.Name = "btnCompute1"
        Me.btnCompute1.Size = New System.Drawing.Size(75, 23)
        Me.btnCompute1.TabIndex = 2
        Me.btnCompute1.Text = "Compute 1"
        Me.btnCompute1.UseVisualStyleBackColor = True
        '
        'dtpIn
        '
        Me.dtpIn.Location = New System.Drawing.Point(221, 55)
        Me.dtpIn.Name = "dtpIn"
        Me.dtpIn.Size = New System.Drawing.Size(200, 20)
        Me.dtpIn.TabIndex = 3
        '
        'lblTotDays
        '
        Me.lblTotDays.AutoSize = True
        Me.lblTotDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotDays.Location = New System.Drawing.Point(193, 157)
        Me.lblTotDays.Name = "lblTotDays"
        Me.lblTotDays.Size = New System.Drawing.Size(41, 15)
        Me.lblTotDays.TabIndex = 5
        Me.lblTotDays.Text = "Label1"
        '
        'txtIn
        '
        Me.txtIn.Location = New System.Drawing.Point(93, 56)
        Me.txtIn.Name = "txtIn"
        Me.txtIn.Size = New System.Drawing.Size(97, 20)
        Me.txtIn.TabIndex = 6
        '
        'txtOut
        '
        Me.txtOut.Location = New System.Drawing.Point(93, 88)
        Me.txtOut.Name = "txtOut"
        Me.txtOut.Size = New System.Drawing.Size(97, 20)
        Me.txtOut.TabIndex = 7
        '
        'btnCompute2
        '
        Me.btnCompute2.Location = New System.Drawing.Point(279, 157)
        Me.btnCompute2.Name = "btnCompute2"
        Me.btnCompute2.Size = New System.Drawing.Size(75, 23)
        Me.btnCompute2.TabIndex = 8
        Me.btnCompute2.Text = "Compute 2"
        Me.btnCompute2.UseVisualStyleBackColor = True
        '
        'dtOut
        '
        Me.dtOut.Location = New System.Drawing.Point(221, 84)
        Me.dtOut.Name = "dtOut"
        Me.dtOut.Size = New System.Drawing.Size(200, 20)
        Me.dtOut.TabIndex = 9
        '
        'PE6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(433, 261)
        Me.Controls.Add(Me.dtOut)
        Me.Controls.Add(Me.btnCompute2)
        Me.Controls.Add(Me.txtOut)
        Me.Controls.Add(Me.txtIn)
        Me.Controls.Add(Me.lblTotDays)
        Me.Controls.Add(Me.dtpIn)
        Me.Controls.Add(Me.btnCompute1)
        Me.Controls.Add(Me.btnOut)
        Me.Controls.Add(Me.btnIn)
        Me.Name = "PE6"
        Me.Text = "PE6"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnIn As System.Windows.Forms.Button
    Friend WithEvents btnOut As System.Windows.Forms.Button
    Friend WithEvents btnCompute1 As System.Windows.Forms.Button
    Friend WithEvents dtpIn As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblTotDays As System.Windows.Forms.Label
    Friend WithEvents txtIn As System.Windows.Forms.TextBox
    Friend WithEvents txtOut As System.Windows.Forms.TextBox
    Friend WithEvents btnCompute2 As System.Windows.Forms.Button
    Friend WithEvents dtOut As System.Windows.Forms.DateTimePicker
End Class
