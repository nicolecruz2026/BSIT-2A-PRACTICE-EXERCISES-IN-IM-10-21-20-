﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim GenRnm As New Random
        Dim GuessNum, GenRndNum As Integer

        txtNumber.Text = GenRnm.Next(1, 10)


        Try
            GuessNum = CInt(txtNumber.Text)
            GenRndNum = GenRnm.Next(1, 10)

            If GuessNum = GenRndNum Then
                MessageBox.Show("That's correct!", "Guessing Game", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("That's Wrong" + vbNewLine + "The correct Answer is: " + CStr(GenRndNum), "Guessing Game", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch MyError As InvalidCastException
            MessageBox.Show("Pls. enter a number...", "Guessing Game")
        End Try
        txtNumber.Text = ""
        txtNumber.Focus()

    End Sub
End Class
