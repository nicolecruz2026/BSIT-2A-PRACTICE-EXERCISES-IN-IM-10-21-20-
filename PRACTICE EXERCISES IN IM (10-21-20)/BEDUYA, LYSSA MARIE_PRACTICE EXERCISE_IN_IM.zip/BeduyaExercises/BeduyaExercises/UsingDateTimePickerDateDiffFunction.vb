﻿Public Class UsingDateTimePickerDateDiffFunction
    Private Sub btnIn_Click(sender As Object, e As EventArgs) Handles btnIn.Click
        txtIn.Text = Today
    End Sub

    Private Sub btnOut_Click(sender As Object, e As EventArgs) Handles btnOut.Click
        txtOut.Text = Today
    End Sub

    Private Sub btnCompute1_Click(sender As Object, e As EventArgs) Handles btnCompute1.Click
        lblTotDays.Text = DateDiff("d", txtIn.Text, txtOut.Text)
    End Sub

    Private Sub btnCompute2_Click(sender As Object, e As EventArgs) Handles btnCompute2.Click
        lblTotDays.Text = DateDiff("d", dtpIn.Text, dtpOut.Text)
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class