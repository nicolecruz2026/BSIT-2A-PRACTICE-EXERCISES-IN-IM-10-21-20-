﻿Public Class RandomGenerator
    Private Sub btnTest_Click(sender As Object, e As EventArgs) Handles btnTest.Click
        Dim GenRnd As New Random
        Dim GuessNum, GenRndNum As Integer
        Try
            GuessNum = CInt(txtNumber.Text)
            GenRndNum = GenRnd.Next(1, 10)
            If GuessNum = GenRndNum Then
                MessageBox.Show("That's correct!", "Guessing Game", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("That's Wrong" + vbNewLine + "The correct Answer is: " + CStr(GenRndNum), "Guessing Game", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch MyError As InvalidCastException
            MessageBox.Show("Pls. enter a number...", "Guessing Game")
        End Try
        txtNumber.Text = ""
        txtNumber.Focus()
    End Sub
End Class
