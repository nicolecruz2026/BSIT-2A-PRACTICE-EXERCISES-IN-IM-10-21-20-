﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UsingDateTimePickerDateDiffFunction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnIn = New System.Windows.Forms.Button()
        Me.btnOut = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dtpOut = New System.Windows.Forms.DateTimePicker()
        Me.dtpIn = New System.Windows.Forms.DateTimePicker()
        Me.txtIn = New System.Windows.Forms.TextBox()
        Me.txtOut = New System.Windows.Forms.TextBox()
        Me.btnCompute1 = New System.Windows.Forms.Button()
        Me.btnCompute2 = New System.Windows.Forms.Button()
        Me.lblTotDays = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnIn
        '
        Me.btnIn.Location = New System.Drawing.Point(12, 35)
        Me.btnIn.Name = "btnIn"
        Me.btnIn.Size = New System.Drawing.Size(75, 23)
        Me.btnIn.TabIndex = 0
        Me.btnIn.Text = "Check In"
        Me.btnIn.UseVisualStyleBackColor = True
        '
        'btnOut
        '
        Me.btnOut.Location = New System.Drawing.Point(12, 64)
        Me.btnOut.Name = "btnOut"
        Me.btnOut.Size = New System.Drawing.Size(75, 23)
        Me.btnOut.TabIndex = 1
        Me.btnOut.Text = "Check Out"
        Me.btnOut.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtpOut)
        Me.GroupBox1.Controls.Add(Me.dtpIn)
        Me.GroupBox1.Location = New System.Drawing.Point(211, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(226, 92)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "DateTimePicker"
        '
        'dtpOut
        '
        Me.dtpOut.Location = New System.Drawing.Point(6, 54)
        Me.dtpOut.Name = "dtpOut"
        Me.dtpOut.Size = New System.Drawing.Size(214, 20)
        Me.dtpOut.TabIndex = 1
        '
        'dtpIn
        '
        Me.dtpIn.Location = New System.Drawing.Point(6, 26)
        Me.dtpIn.Name = "dtpIn"
        Me.dtpIn.Size = New System.Drawing.Size(214, 20)
        Me.dtpIn.TabIndex = 0
        '
        'txtIn
        '
        Me.txtIn.Location = New System.Drawing.Point(93, 38)
        Me.txtIn.Name = "txtIn"
        Me.txtIn.Size = New System.Drawing.Size(100, 20)
        Me.txtIn.TabIndex = 3
        '
        'txtOut
        '
        Me.txtOut.Location = New System.Drawing.Point(93, 66)
        Me.txtOut.Name = "txtOut"
        Me.txtOut.Size = New System.Drawing.Size(100, 20)
        Me.txtOut.TabIndex = 4
        '
        'btnCompute1
        '
        Me.btnCompute1.Location = New System.Drawing.Point(74, 130)
        Me.btnCompute1.Name = "btnCompute1"
        Me.btnCompute1.Size = New System.Drawing.Size(75, 23)
        Me.btnCompute1.TabIndex = 5
        Me.btnCompute1.Text = "Compute 1"
        Me.btnCompute1.UseVisualStyleBackColor = True
        '
        'btnCompute2
        '
        Me.btnCompute2.Location = New System.Drawing.Point(295, 130)
        Me.btnCompute2.Name = "btnCompute2"
        Me.btnCompute2.Size = New System.Drawing.Size(75, 23)
        Me.btnCompute2.TabIndex = 6
        Me.btnCompute2.Text = "Compute2"
        Me.btnCompute2.UseVisualStyleBackColor = True
        '
        'lblTotDays
        '
        Me.lblTotDays.AutoSize = True
        Me.lblTotDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotDays.Location = New System.Drawing.Point(213, 135)
        Me.lblTotDays.Name = "lblTotDays"
        Me.lblTotDays.Size = New System.Drawing.Size(18, 15)
        Me.lblTotDays.TabIndex = 7
        Me.lblTotDays.Text = "   "
        Me.lblTotDays.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(193, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Total Days"
        '
        'UsingDateTimePickerDateDiffFunction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(449, 162)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblTotDays)
        Me.Controls.Add(Me.btnCompute2)
        Me.Controls.Add(Me.btnCompute1)
        Me.Controls.Add(Me.txtOut)
        Me.Controls.Add(Me.txtIn)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnOut)
        Me.Controls.Add(Me.btnIn)
        Me.Name = "UsingDateTimePickerDateDiffFunction"
        Me.Text = "UsingDateTimePickerDateDiffFunction"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnIn As Button
    Friend WithEvents btnOut As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents dtpOut As DateTimePicker
    Friend WithEvents dtpIn As DateTimePicker
    Friend WithEvents txtIn As TextBox
    Friend WithEvents txtOut As TextBox
    Friend WithEvents btnCompute1 As Button
    Friend WithEvents btnCompute2 As Button
    Friend WithEvents lblTotDays As Label
    Friend WithEvents Label2 As Label
End Class
