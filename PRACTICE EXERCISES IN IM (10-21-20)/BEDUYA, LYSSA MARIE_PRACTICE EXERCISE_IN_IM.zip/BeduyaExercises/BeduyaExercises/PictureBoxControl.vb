﻿Public Class PictureBoxControl
    Private Sub btnAction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShow.Click, btnDisable.Click, btnEnable.Click, btnHide.Click
        If sender Is btnShow Then
            picBaby.Visible = True
        ElseIf sender Is btnHide Then
            picBaby.Visible = False
        ElseIf sender Is btnEnable Then
            btnShow.Enabled = True
            btnHide.Enabled = True
        ElseIf sender Is btnDisable Then
            btnShow.Enabled = False
            btnHide.Enabled = False
        End If
    End Sub
End Class