﻿Public Class _2ListBoxControlObject
    Private Sub lst1_DoubleClick(sender As Object, e As EventArgs) Handles lst1.SelectedIndexChanged
        Dim i As Byte
        For i = 0 To lst1.Items.Count
            If lst1.SelectedIndex = i Then
                lst2.Items.Add(lst1.SelectedItem)
            End If
        Next
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lst1.ClearSelected()
        lst2.Items.Clear()
    End Sub

    Private Sub btnClearAll_Click(sender As Object, e As EventArgs) Handles btnClearAll.Click
        Dim i As Integer

        For i = 0 To lst2.Items.Count
            If lst2.SelectedIndex = i Then
                lst2.Items.RemoveAt(i)
            End If
        Next i
    End Sub
End Class