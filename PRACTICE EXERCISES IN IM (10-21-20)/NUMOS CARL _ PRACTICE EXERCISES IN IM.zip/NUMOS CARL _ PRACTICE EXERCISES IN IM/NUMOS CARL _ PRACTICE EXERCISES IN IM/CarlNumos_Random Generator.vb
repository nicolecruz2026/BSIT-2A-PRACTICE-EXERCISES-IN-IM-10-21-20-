﻿Public Class CarlNumos_RandomGenerator

    Private Sub btnTest_Click_Click(sender As Object, e As EventArgs) Handles btnTest_Click.Click
        Dim GenRnd As New Random
        txtNumber.Text = GenRnd.Next(1, 10)
    End Sub
End Class
