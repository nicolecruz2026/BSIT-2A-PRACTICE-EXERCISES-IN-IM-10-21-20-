﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CarlNumos_RandomGenerator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnTest_Click = New System.Windows.Forms.Button()
        Me.Label1s = New System.Windows.Forms.Label()
        Me.txtNumber = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(41, 78)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(158, 27)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "                        "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(49, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(145, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Computer Generated Number"
        '
        'btnTest_Click
        '
        Me.btnTest_Click.Location = New System.Drawing.Point(84, 136)
        Me.btnTest_Click.Name = "btnTest_Click"
        Me.btnTest_Click.Size = New System.Drawing.Size(75, 40)
        Me.btnTest_Click.TabIndex = 5
        Me.btnTest_Click.Text = "Test"
        Me.btnTest_Click.UseVisualStyleBackColor = True
        '
        'Label1s
        '
        Me.Label1s.AutoSize = True
        Me.Label1s.Location = New System.Drawing.Point(117, 87)
        Me.Label1s.Name = "Label1s"
        Me.Label1s.Size = New System.Drawing.Size(0, 13)
        Me.Label1s.TabIndex = 8
        '
        'txtNumber
        '
        Me.txtNumber.AutoSize = True
        Me.txtNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNumber.Location = New System.Drawing.Point(109, 81)
        Me.txtNumber.Name = "txtNumber"
        Me.txtNumber.Size = New System.Drawing.Size(0, 24)
        Me.txtNumber.TabIndex = 9
        '
        'CarlNumos_RandomGenerator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(243, 213)
        Me.Controls.Add(Me.txtNumber)
        Me.Controls.Add(Me.Label1s)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnTest_Click)
        Me.Name = "CarlNumos_RandomGenerator"
        Me.Text = "Random Generator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnTest_Click As System.Windows.Forms.Button
    Friend WithEvents Label1s As System.Windows.Forms.Label
    Friend WithEvents txtNumber As System.Windows.Forms.Label

End Class
