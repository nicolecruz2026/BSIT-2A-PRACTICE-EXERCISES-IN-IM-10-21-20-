﻿Public Class CarlNumos_Random_Generator2

    Private Sub btnTest_Click_Click(sender As Object, e As EventArgs) Handles btnTest_Click.Click
        Dim GenRnd As New Random
        Dim GuessNum, GenRndNum As Integer
        Try
            GuessNum = CInt(txtNumber.Text)
            GenRndNum = GenRnd.Next(1, 10)
            If GuessNum = GenRndNum Then
                MessageBox.Show("That's correct!", "Guessing Game", _
                MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("That's Wrong" + vbNewLine + _
                "The correct Answer is: " + CStr(GenRndNum), _
                "Guessing Game", MessageBoxButtons.OK, _
                MessageBoxIcon.Information)
            End If
        Catch MyError As InvalidCastException
            MessageBox.Show("Pls. enter a number...", "Guessing Game")
        End Try
        txtNumber.Text = ""
        txtNumber.Focus()
    End Sub
End Class