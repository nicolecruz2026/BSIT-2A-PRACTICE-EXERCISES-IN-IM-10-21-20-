﻿Public Class CarlNumos_LuckySevenProgram

    Private Sub btnSpin_Click(sender As Object, e As EventArgs) Handles btnSpin.Click

        Dim RndGen As New Random
        Dim N1, N2, N3 As Integer
        N1 = RndGen.Next(1, 10)
        N2 = RndGen.Next(1, 10)
        N3 = RndGen.Next(1, 10)
        lblNum1.Text = N1
        lblNum2.Text = N2
        lblNum3.Text = N3
        If N1 = 7 Or N2 = 7 OrElse N3 = 7 Then
            MessageBox.Show("Congrats! You win...", "Lucky Seven")
        Else
            MessageBox.Show("Sorry! You lose...", "Lucky Seven")
        End If
    End Sub


End Class