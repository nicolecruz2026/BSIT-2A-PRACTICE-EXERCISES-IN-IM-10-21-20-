﻿Public Class PRACTICEEXCERCISE5

    Private Sub First1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles First1.SelectedIndexChanged
        If First1.SelectedIndex = 0 Then
            First2.Items.Add(First1.SelectedItem)
        End If
        If First1.SelectedIndex = 1 Then
            First2.Items.Add(First1.SelectedItem)
        End If
        If First1.SelectedIndex = 2 Then
            First2.Items.Add(First1.SelectedItem)
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAll.Click
        First1.ClearSelected()
        First2.Items.Clear()
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Dim i As Integer

        For i = 0 To First2.Items.Count
            If First2.SelectedIndex = i Then
                First2.Items.RemoveAt(i)
            End If
        Next i
    End Sub
End Class