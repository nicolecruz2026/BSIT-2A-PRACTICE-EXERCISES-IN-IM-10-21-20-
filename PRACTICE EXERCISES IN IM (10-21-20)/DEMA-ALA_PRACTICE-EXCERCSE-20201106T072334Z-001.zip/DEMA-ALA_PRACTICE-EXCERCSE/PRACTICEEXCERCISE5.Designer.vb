﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PRACTICEEXCERCISE5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.First1 = New System.Windows.Forms.ListBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.First2 = New System.Windows.Forms.ListBox()
        Me.btnClearAll = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.First1)
        Me.GroupBox1.Location = New System.Drawing.Point(52, 52)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(157, 205)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "UNDERWEAR"
        '
        'First1
        '
        Me.First1.FormattingEnabled = True
        Me.First1.Items.AddRange(New Object() {"Bra", "Panty", "Brief", "Sando"})
        Me.First1.Location = New System.Drawing.Point(16, 29)
        Me.First1.Name = "First1"
        Me.First1.Size = New System.Drawing.Size(110, 160)
        Me.First1.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.First2)
        Me.GroupBox2.Location = New System.Drawing.Point(263, 52)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(155, 205)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "SELECT UNDERWEAR"
        '
        'First2
        '
        Me.First2.FormattingEnabled = True
        Me.First2.Location = New System.Drawing.Point(29, 29)
        Me.First2.Name = "First2"
        Me.First2.Size = New System.Drawing.Size(110, 160)
        Me.First2.TabIndex = 1
        '
        'btnClearAll
        '
        Me.btnClearAll.Location = New System.Drawing.Point(87, 284)
        Me.btnClearAll.Name = "btnClearAll"
        Me.btnClearAll.Size = New System.Drawing.Size(91, 34)
        Me.btnClearAll.TabIndex = 2
        Me.btnClearAll.Text = "CLEAR &ALL"
        Me.btnClearAll.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(263, 284)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(155, 34)
        Me.btnClear.TabIndex = 3
        Me.btnClear.Text = "&CLEAR SELECTED ITEMS"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'PRACTICEEXCERCISE5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(498, 400)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnClearAll)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "PRACTICEEXCERCISE5"
        Me.Text = "2 List Box control/object"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnClearAll As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents First1 As System.Windows.Forms.ListBox
    Friend WithEvents First2 As System.Windows.Forms.ListBox
End Class
