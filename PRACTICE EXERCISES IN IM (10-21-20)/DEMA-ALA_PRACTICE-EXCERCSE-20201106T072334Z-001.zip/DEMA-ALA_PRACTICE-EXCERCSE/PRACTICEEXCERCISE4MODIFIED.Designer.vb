﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PRACTICEEXCERCISE4MODIFIED
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rchMeaning = New System.Windows.Forms.RichTextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.FirstTerms = New System.Windows.Forms.ListBox()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rchMeaning)
        Me.GroupBox2.Location = New System.Drawing.Point(236, 35)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(260, 147)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Meaning"
        '
        'rchMeaning
        '
        Me.rchMeaning.Location = New System.Drawing.Point(6, 28)
        Me.rchMeaning.Name = "rchMeaning"
        Me.rchMeaning.Size = New System.Drawing.Size(248, 108)
        Me.rchMeaning.TabIndex = 0
        Me.rchMeaning.Text = ""
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.FirstTerms)
        Me.GroupBox1.Location = New System.Drawing.Point(42, 35)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(165, 147)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Internet Termenologies"
        '
        'FirstTerms
        '
        Me.FirstTerms.FormattingEnabled = True
        Me.FirstTerms.Items.AddRange(New Object() {"Packet", "Router", "Firewall", "Telnet", "Protocol"})
        Me.FirstTerms.Location = New System.Drawing.Point(6, 28)
        Me.FirstTerms.Name = "FirstTerms"
        Me.FirstTerms.Size = New System.Drawing.Size(135, 108)
        Me.FirstTerms.TabIndex = 2
        '
        'PRACTICEEXCERCISE4MODIFIED
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(638, 370)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "PRACTICEEXCERCISE4MODIFIED"
        Me.Text = "PRACTICEEXCERCISE4MODIFIED"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rchMeaning As System.Windows.Forms.RichTextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents FirstTerms As System.Windows.Forms.ListBox
End Class
