﻿Public Class EXERCISE04AsisJerieson

    Private Sub lstTerms_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstTerms.SelectedIndexChanged
        Dim Means As String

        Select lstTerms.SelectedIndex
            Case 0
                Means = " - A small piece of message that is transported over the Internet."

            Case 1
                Means = " - A special-purpose computer that directs packets of data along a network."

            Case 2
                Means = " - A security mechanism that organizations use to protect their intranet from the Internet."

            Case 3
                Means = " - A program that allows you to log into a remote computer."

            Case 4
                Means = " - A set of precisely specified rules for carrying out a procedure."

        End Select
        rchMeaning.Text = Means
    End Sub
End Class