﻿Public Class EXERCISE01AsisJerieson

    Private Sub btnTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest.Click
        Dim GenRnd As New Random
        txtNumber.Text = GenRnd.Next(1, 10)
    End Sub

    Private Sub EXERCISE01AsisJerieson_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
