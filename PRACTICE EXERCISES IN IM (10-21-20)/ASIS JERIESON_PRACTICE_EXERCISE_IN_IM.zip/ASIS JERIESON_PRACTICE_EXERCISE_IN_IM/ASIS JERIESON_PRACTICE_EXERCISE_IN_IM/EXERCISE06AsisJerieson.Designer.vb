﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EXERCISE06AsisJerieson
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnIn = New System.Windows.Forms.Button()
        Me.btnOut = New System.Windows.Forms.Button()
        Me.txtIn = New System.Windows.Forms.TextBox()
        Me.txtOut = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dtpOut = New System.Windows.Forms.DateTimePicker()
        Me.dtpIn = New System.Windows.Forms.DateTimePicker()
        Me.btnCompute1 = New System.Windows.Forms.Button()
        Me.btnCompute2 = New System.Windows.Forms.Button()
        Me.lblTotDays = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnIn
        '
        Me.btnIn.Location = New System.Drawing.Point(12, 44)
        Me.btnIn.Name = "btnIn"
        Me.btnIn.Size = New System.Drawing.Size(103, 36)
        Me.btnIn.TabIndex = 0
        Me.btnIn.Text = "Check-In"
        Me.btnIn.UseVisualStyleBackColor = True
        '
        'btnOut
        '
        Me.btnOut.Location = New System.Drawing.Point(13, 85)
        Me.btnOut.Name = "btnOut"
        Me.btnOut.Size = New System.Drawing.Size(103, 34)
        Me.btnOut.TabIndex = 1
        Me.btnOut.Text = "Check-Out"
        Me.btnOut.UseVisualStyleBackColor = True
        '
        'txtIn
        '
        Me.txtIn.Location = New System.Drawing.Point(122, 53)
        Me.txtIn.Name = "txtIn"
        Me.txtIn.Size = New System.Drawing.Size(100, 20)
        Me.txtIn.TabIndex = 2
        '
        'txtOut
        '
        Me.txtOut.Location = New System.Drawing.Point(122, 93)
        Me.txtOut.Name = "txtOut"
        Me.txtOut.Size = New System.Drawing.Size(100, 20)
        Me.txtOut.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtpOut)
        Me.GroupBox1.Controls.Add(Me.dtpIn)
        Me.GroupBox1.Location = New System.Drawing.Point(251, 22)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 126)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Date Time Picker"
        '
        'dtpOut
        '
        Me.dtpOut.Location = New System.Drawing.Point(31, 70)
        Me.dtpOut.Name = "dtpOut"
        Me.dtpOut.Size = New System.Drawing.Size(135, 20)
        Me.dtpOut.TabIndex = 1
        '
        'dtpIn
        '
        Me.dtpIn.Location = New System.Drawing.Point(31, 31)
        Me.dtpIn.Name = "dtpIn"
        Me.dtpIn.Size = New System.Drawing.Size(135, 20)
        Me.dtpIn.TabIndex = 0
        '
        'btnCompute1
        '
        Me.btnCompute1.Location = New System.Drawing.Point(39, 166)
        Me.btnCompute1.Name = "btnCompute1"
        Me.btnCompute1.Size = New System.Drawing.Size(124, 41)
        Me.btnCompute1.TabIndex = 5
        Me.btnCompute1.Text = "Compute 1"
        Me.btnCompute1.UseVisualStyleBackColor = True
        '
        'btnCompute2
        '
        Me.btnCompute2.Location = New System.Drawing.Point(282, 166)
        Me.btnCompute2.Name = "btnCompute2"
        Me.btnCompute2.Size = New System.Drawing.Size(124, 41)
        Me.btnCompute2.TabIndex = 6
        Me.btnCompute2.Text = "Compute 2"
        Me.btnCompute2.UseVisualStyleBackColor = True
        '
        'lblTotDays
        '
        Me.lblTotDays.Location = New System.Drawing.Point(197, 170)
        Me.lblTotDays.Name = "lblTotDays"
        Me.lblTotDays.Size = New System.Drawing.Size(49, 37)
        Me.lblTotDays.TabIndex = 7
        Me.lblTotDays.Text = "Label1"
        Me.lblTotDays.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(186, 151)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Total of Days"
        '
        'EXERCISE06AsisJerieson
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(464, 261)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblTotDays)
        Me.Controls.Add(Me.btnCompute2)
        Me.Controls.Add(Me.btnCompute1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtOut)
        Me.Controls.Add(Me.txtIn)
        Me.Controls.Add(Me.btnOut)
        Me.Controls.Add(Me.btnIn)
        Me.Name = "EXERCISE06AsisJerieson"
        Me.Text = "EXERCISE06AsisJerieson"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnIn As System.Windows.Forms.Button
    Friend WithEvents btnOut As System.Windows.Forms.Button
    Friend WithEvents txtIn As System.Windows.Forms.TextBox
    Friend WithEvents txtOut As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dtpOut As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpIn As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnCompute1 As System.Windows.Forms.Button
    Friend WithEvents btnCompute2 As System.Windows.Forms.Button
    Friend WithEvents lblTotDays As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
