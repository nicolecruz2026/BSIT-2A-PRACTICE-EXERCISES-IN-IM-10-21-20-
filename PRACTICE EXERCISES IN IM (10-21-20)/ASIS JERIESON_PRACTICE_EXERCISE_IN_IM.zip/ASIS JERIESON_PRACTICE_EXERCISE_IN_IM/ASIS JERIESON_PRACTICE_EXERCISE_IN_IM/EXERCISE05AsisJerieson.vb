﻿Public Class EXERCISE05AsisJerieson

    Private Sub lst1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lst1.SelectedIndexChanged
        If lst1.SelectedIndex = 0 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If
        If lst1.SelectedIndex = 1 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If
        If lst1.SelectedIndex = 2 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim i As Integer
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        lst1.ClearSelected()
        lst2.Items.Clear()
    End Sub

    Private Sub EXERCISE05AsisJerieson_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class