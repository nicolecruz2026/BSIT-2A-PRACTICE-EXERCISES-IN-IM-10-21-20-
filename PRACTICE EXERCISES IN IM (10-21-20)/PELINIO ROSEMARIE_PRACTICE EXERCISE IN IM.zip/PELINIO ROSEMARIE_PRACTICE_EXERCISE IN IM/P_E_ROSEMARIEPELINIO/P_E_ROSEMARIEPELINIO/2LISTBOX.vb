﻿Public Class _2LISTBOX

    Private Sub lst1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lst1.SelectedIndexChanged
        Dim i As Byte
        For i = 0 To lst1.Items.Count
            If lst1.SelectedIndex = i Then
                lst2.Items.Add(lst1.SelectedItem)
            End If
        Next

        If lst1.SelectedIndex = 0 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If
        If lst1.SelectedIndex = 1 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If
        If lst1.SelectedIndex = 2 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Dim i As Integer
        For i = 0 To lst2.Items.Count
            If lst2.SelectedIndex = i Then
                lst2.Items.RemoveAt(i)
            End If
        Next i

    End Sub

    Private Sub btnClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAll.Click
         lst1.ClearSelected()
        lst2.Items.Clear()
    End Sub
End Class