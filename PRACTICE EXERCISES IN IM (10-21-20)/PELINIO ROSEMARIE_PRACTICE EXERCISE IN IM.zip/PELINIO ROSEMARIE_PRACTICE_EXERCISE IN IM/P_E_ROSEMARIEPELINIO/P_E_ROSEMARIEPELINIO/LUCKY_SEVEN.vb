﻿Public Class LUCKY_SEVEN

    Private Sub btnSpin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSpin.Click
        Dim RndGen As New Random
        Dim Num1, Num2, Num3 As Integer

        Num1 = RndGen.Next(1, 10)
        Num2 = RndGen.Next(1, 10)
        Num3 = RndGen.Next(1, 10)
        lblNum1.Text = Num1
        lblNum2.Text = Num2
        lblNum3.Text = Num3
        If Num1 = 7 Or Num2 = 7 OrElse Num3 = 7 Then
            MessageBox.Show("Congrats! You Win...", "Lucky Seven")
        Else
            MessageBox.Show("Sorry! You Lose...", "Lucky Seven")
        End If
    End Sub

End Class