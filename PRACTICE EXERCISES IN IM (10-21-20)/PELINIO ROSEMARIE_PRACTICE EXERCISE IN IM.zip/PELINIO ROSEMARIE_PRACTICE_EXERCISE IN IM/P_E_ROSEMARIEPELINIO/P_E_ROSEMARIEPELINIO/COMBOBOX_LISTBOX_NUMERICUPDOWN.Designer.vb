﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class COMBOBOX_LISTBOX_NUMERICUPDOWN
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lstParts = New System.Windows.Forms.ListBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.cboDisc = New System.Windows.Forms.ComboBox()
        Me.btnCompute = New System.Windows.Forms.Button()
        Me.label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label5 = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.txtUPrice = New System.Windows.Forms.TextBox()
        Me.txtSubTot = New System.Windows.Forms.TextBox()
        Me.txtDisc = New System.Windows.Forms.TextBox()
        Me.txtTotAmt = New System.Windows.Forms.TextBox()
        Me.nudQuan = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.nudQuan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lstParts)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(174, 136)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Computer Parts"
        '
        'lstParts
        '
        Me.lstParts.FormattingEnabled = True
        Me.lstParts.ItemHeight = 16
        Me.lstParts.Items.AddRange(New Object() {"Monitor", "Keyboard", "Mouse", "Hard Disk", "Disk Drive"})
        Me.lstParts.Location = New System.Drawing.Point(37, 21)
        Me.lstParts.Name = "lstParts"
        Me.lstParts.Size = New System.Drawing.Size(102, 100)
        Me.lstParts.TabIndex = 15
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.cboDisc)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(12, 166)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(174, 62)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Discount Rate"
        '
        'cboDisc
        '
        Me.cboDisc.FormattingEnabled = True
        Me.cboDisc.Items.AddRange(New Object() {"5%", "10%", "15%", "No Discount"})
        Me.cboDisc.Location = New System.Drawing.Point(24, 29)
        Me.cboDisc.Name = "cboDisc"
        Me.cboDisc.Size = New System.Drawing.Size(127, 24)
        Me.cboDisc.TabIndex = 15
        '
        'btnCompute
        '
        Me.btnCompute.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnCompute.Location = New System.Drawing.Point(12, 235)
        Me.btnCompute.Name = "btnCompute"
        Me.btnCompute.Size = New System.Drawing.Size(174, 23)
        Me.btnCompute.TabIndex = 2
        Me.btnCompute.Text = "Compute"
        Me.btnCompute.UseVisualStyleBackColor = True
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(220, 31)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(68, 16)
        Me.label1.TabIndex = 3
        Me.label1.Text = "Unit Price:"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(220, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 16)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Quality:"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New System.Drawing.Point(220, 116)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(70, 16)
        Me.label3.TabIndex = 5
        Me.label3.Text = "Sub-Total:"
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label4.Location = New System.Drawing.Point(220, 157)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(63, 16)
        Me.label4.TabIndex = 6
        Me.label4.Text = "Discount:"
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label5.Location = New System.Drawing.Point(201, 198)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(90, 16)
        Me.label5.TabIndex = 7
        Me.label5.Text = "Total Amount:"
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(192, 235)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(99, 23)
        Me.btnClear.TabIndex = 8
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(292, 235)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(99, 23)
        Me.btnClose.TabIndex = 9
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'txtUPrice
        '
        Me.txtUPrice.Location = New System.Drawing.Point(301, 27)
        Me.txtUPrice.Name = "txtUPrice"
        Me.txtUPrice.Size = New System.Drawing.Size(90, 20)
        Me.txtUPrice.TabIndex = 10
        Me.txtUPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtSubTot
        '
        Me.txtSubTot.Location = New System.Drawing.Point(301, 112)
        Me.txtSubTot.Name = "txtSubTot"
        Me.txtSubTot.Size = New System.Drawing.Size(90, 20)
        Me.txtSubTot.TabIndex = 11
        Me.txtSubTot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtDisc
        '
        Me.txtDisc.Location = New System.Drawing.Point(301, 156)
        Me.txtDisc.Name = "txtDisc"
        Me.txtDisc.Size = New System.Drawing.Size(90, 20)
        Me.txtDisc.TabIndex = 12
        Me.txtDisc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTotAmt
        '
        Me.txtTotAmt.Location = New System.Drawing.Point(301, 196)
        Me.txtTotAmt.Name = "txtTotAmt"
        Me.txtTotAmt.Size = New System.Drawing.Size(90, 20)
        Me.txtTotAmt.TabIndex = 13
        Me.txtTotAmt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'nudQuan
        '
        Me.nudQuan.Location = New System.Drawing.Point(348, 71)
        Me.nudQuan.Name = "nudQuan"
        Me.nudQuan.Size = New System.Drawing.Size(43, 20)
        Me.nudQuan.TabIndex = 14
        Me.nudQuan.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'COMBOBOX_LISTBOX_NUMERICUPDOWN
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(403, 270)
        Me.Controls.Add(Me.nudQuan)
        Me.Controls.Add(Me.txtTotAmt)
        Me.Controls.Add(Me.txtDisc)
        Me.Controls.Add(Me.txtSubTot)
        Me.Controls.Add(Me.txtUPrice)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.btnCompute)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "COMBOBOX_LISTBOX_NUMERICUPDOWN"
        Me.Text = "COMBO BOX, LISTBOX AND NUMERIC UPDOWN"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.nudQuan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lstParts As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents cboDisc As System.Windows.Forms.ComboBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents txtUPrice As System.Windows.Forms.TextBox
    Friend WithEvents txtSubTot As System.Windows.Forms.TextBox
    Friend WithEvents txtDisc As System.Windows.Forms.TextBox
    Friend WithEvents txtTotAmt As System.Windows.Forms.TextBox
    Friend WithEvents nudQuan As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnCompute As System.Windows.Forms.Button
End Class
