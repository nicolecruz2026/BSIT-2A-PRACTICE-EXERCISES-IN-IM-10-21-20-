﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DATETIMEPICKER
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnIn = New System.Windows.Forms.Button()
        Me.btnOut = New System.Windows.Forms.Button()
        Me.btnCompute1 = New System.Windows.Forms.Button()
        Me.btnCompute2 = New System.Windows.Forms.Button()
        Me.txtIn = New System.Windows.Forms.TextBox()
        Me.txtOut = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dtpOut = New System.Windows.Forms.DateTimePicker()
        Me.dtpIn = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtTotDays = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnIn
        '
        Me.btnIn.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnIn.Location = New System.Drawing.Point(31, 52)
        Me.btnIn.Name = "btnIn"
        Me.btnIn.Size = New System.Drawing.Size(109, 30)
        Me.btnIn.TabIndex = 0
        Me.btnIn.Text = "Check In"
        Me.btnIn.UseVisualStyleBackColor = True
        '
        'btnOut
        '
        Me.btnOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOut.Location = New System.Drawing.Point(31, 102)
        Me.btnOut.Name = "btnOut"
        Me.btnOut.Size = New System.Drawing.Size(109, 27)
        Me.btnOut.TabIndex = 1
        Me.btnOut.Text = "Check Out"
        Me.btnOut.UseVisualStyleBackColor = True
        '
        'btnCompute1
        '
        Me.btnCompute1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCompute1.Location = New System.Drawing.Point(56, 195)
        Me.btnCompute1.Name = "btnCompute1"
        Me.btnCompute1.Size = New System.Drawing.Size(109, 39)
        Me.btnCompute1.TabIndex = 2
        Me.btnCompute1.Text = "Compute 1"
        Me.btnCompute1.UseVisualStyleBackColor = True
        '
        'btnCompute2
        '
        Me.btnCompute2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCompute2.Location = New System.Drawing.Point(402, 189)
        Me.btnCompute2.Name = "btnCompute2"
        Me.btnCompute2.Size = New System.Drawing.Size(109, 39)
        Me.btnCompute2.TabIndex = 3
        Me.btnCompute2.Text = "Compute 2"
        Me.btnCompute2.UseVisualStyleBackColor = True
        '
        'txtIn
        '
        Me.txtIn.Location = New System.Drawing.Point(179, 57)
        Me.txtIn.Name = "txtIn"
        Me.txtIn.Size = New System.Drawing.Size(100, 22)
        Me.txtIn.TabIndex = 4
        Me.txtIn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtOut
        '
        Me.txtOut.Location = New System.Drawing.Point(179, 107)
        Me.txtOut.Name = "txtOut"
        Me.txtOut.Size = New System.Drawing.Size(100, 22)
        Me.txtOut.TabIndex = 5
        Me.txtOut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtpOut)
        Me.GroupBox1.Controls.Add(Me.dtpIn)
        Me.GroupBox1.Location = New System.Drawing.Point(300, 43)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(246, 100)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "DateTimePicker"
        '
        'dtpOut
        '
        Me.dtpOut.Location = New System.Drawing.Point(17, 64)
        Me.dtpOut.Name = "dtpOut"
        Me.dtpOut.Size = New System.Drawing.Size(223, 22)
        Me.dtpOut.TabIndex = 1
        '
        'dtpIn
        '
        Me.dtpIn.Location = New System.Drawing.Point(17, 21)
        Me.dtpIn.Name = "dtpIn"
        Me.dtpIn.Size = New System.Drawing.Size(223, 22)
        Me.dtpIn.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(209, 160)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 16)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Total Days"
        '
        'txtTotDays
        '
        Me.txtTotDays.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotDays.Location = New System.Drawing.Point(261, 180)
        Me.txtTotDays.Multiline = True
        Me.txtTotDays.Name = "txtTotDays"
        Me.txtTotDays.Size = New System.Drawing.Size(67, 54)
        Me.txtTotDays.TabIndex = 8
        Me.txtTotDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'DATETIMEPICKER
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(561, 255)
        Me.Controls.Add(Me.txtTotDays)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtOut)
        Me.Controls.Add(Me.txtIn)
        Me.Controls.Add(Me.btnCompute2)
        Me.Controls.Add(Me.btnCompute1)
        Me.Controls.Add(Me.btnOut)
        Me.Controls.Add(Me.btnIn)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "DATETIMEPICKER"
        Me.Text = "USING DATE TIMEPICKER AND DATEDIFF FUCTION"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnIn As System.Windows.Forms.Button
    Friend WithEvents btnOut As System.Windows.Forms.Button
    Friend WithEvents btnCompute1 As System.Windows.Forms.Button
    Friend WithEvents btnCompute2 As System.Windows.Forms.Button
    Friend WithEvents txtIn As System.Windows.Forms.TextBox
    Friend WithEvents txtOut As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dtpOut As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpIn As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtTotDays As System.Windows.Forms.TextBox
End Class
