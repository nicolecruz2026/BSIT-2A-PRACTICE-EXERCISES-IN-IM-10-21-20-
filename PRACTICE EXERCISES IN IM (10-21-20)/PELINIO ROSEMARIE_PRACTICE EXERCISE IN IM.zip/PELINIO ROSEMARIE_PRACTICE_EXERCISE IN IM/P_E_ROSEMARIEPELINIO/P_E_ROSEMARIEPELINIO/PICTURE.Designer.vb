﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PICTURE
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picBaby = New System.Windows.Forms.PictureBox()
        Me.btnShow = New System.Windows.Forms.Button()
        Me.btnHide = New System.Windows.Forms.Button()
        Me.btnEnables = New System.Windows.Forms.Button()
        Me.btnDisable = New System.Windows.Forms.Button()
        CType(Me.picBaby, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picBaby
        '
        Me.picBaby.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picBaby.Image = Global.P_E_ROSEMARIEPELINIO.My.Resources.Resources.picBaby
        Me.picBaby.Location = New System.Drawing.Point(28, 12)
        Me.picBaby.Name = "picBaby"
        Me.picBaby.Size = New System.Drawing.Size(226, 166)
        Me.picBaby.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBaby.TabIndex = 0
        Me.picBaby.TabStop = False
        '
        'btnShow
        '
        Me.btnShow.Location = New System.Drawing.Point(28, 192)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(114, 23)
        Me.btnShow.TabIndex = 1
        Me.btnShow.Text = "SHOW"
        Me.btnShow.UseVisualStyleBackColor = True
        '
        'btnHide
        '
        Me.btnHide.Location = New System.Drawing.Point(148, 192)
        Me.btnHide.Name = "btnHide"
        Me.btnHide.Size = New System.Drawing.Size(106, 23)
        Me.btnHide.TabIndex = 2
        Me.btnHide.Text = "HIDE"
        Me.btnHide.UseVisualStyleBackColor = True
        '
        'btnEnables
        '
        Me.btnEnables.Location = New System.Drawing.Point(28, 221)
        Me.btnEnables.Name = "btnEnables"
        Me.btnEnables.Size = New System.Drawing.Size(114, 23)
        Me.btnEnables.TabIndex = 3
        Me.btnEnables.Text = "ENABLE"
        Me.btnEnables.UseVisualStyleBackColor = True
        '
        'btnDisable
        '
        Me.btnDisable.Location = New System.Drawing.Point(148, 221)
        Me.btnDisable.Name = "btnDisable"
        Me.btnDisable.Size = New System.Drawing.Size(106, 23)
        Me.btnDisable.TabIndex = 4
        Me.btnDisable.Text = "DISABLE"
        Me.btnDisable.UseVisualStyleBackColor = True
        '
        'PICTURE
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.btnDisable)
        Me.Controls.Add(Me.btnEnables)
        Me.Controls.Add(Me.btnHide)
        Me.Controls.Add(Me.btnShow)
        Me.Controls.Add(Me.picBaby)
        Me.Name = "PICTURE"
        Me.Text = "PICTURE"
        CType(Me.picBaby, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picBaby As System.Windows.Forms.PictureBox
    Friend WithEvents btnShow As System.Windows.Forms.Button
    Friend WithEvents btnHide As System.Windows.Forms.Button
    Friend WithEvents btnEnables As System.Windows.Forms.Button
    Friend WithEvents btnDisable As System.Windows.Forms.Button
End Class
