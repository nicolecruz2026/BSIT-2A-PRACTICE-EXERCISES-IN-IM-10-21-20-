﻿Public Class RANDOM_GENERATOR


    Private Sub btnTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest.Click
        Dim GenRnd As New Random
        Dim GuessNum, GenRndNum As Integer

        txtNumber.Text = GenRnd.Next(1, 10)

        Try
            GuessNum = CInt(txtNumber.Text)
            GenRndNum = GenRnd.Next(1, 10)
            If GuessNum = GenRndNum Then
                MessageBox.Show("That's Correct!", "Guessing Game", _
                MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("That's Wrong" + vbNewLine + _
                "The Correct Answer is: " + CStr(GenRndNum), _
                "Guessing Game", MessageBoxButtons.OK, _
                MessageBoxIcon.Information)
            End If
        Catch MyError As InvalidCastException
            MessageBox.Show("Please Enter a Number...", "Guessing Game")
        End Try
        txtNumber.Text = ""
        txtNumber.Focus()
    End Sub

End Class
