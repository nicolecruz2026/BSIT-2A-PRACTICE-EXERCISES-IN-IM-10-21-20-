﻿Public Class Exercise5_Tumala_Pauline

    Private Sub Exercise5_Tumala_Pauline_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lst1.SelectedIndexChanged


        Dim i As Byte
        For i = 0 To lst1.Items.Count
            If lst1.SelectedIndex = i Then
                lst2.Items.Add(lst1.SelectedItem)
            End If
        Next



        If lst1.SelectedIndex = 0 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If
        If lst1.SelectedIndex = 1 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If
        If lst1.SelectedIndex = 2 Then
            lst2.Items.Add(lst1.SelectedItem)
        End If

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAll.Click
        lst1.ClearSelected()
        lst2.Items.Clear()

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Dim i As Integer
        For i = 0 To lst2.Items.Count
            If lst2.SelectedIndex = i Then
                lst2.Items.RemoveAt(i)
            End If
        Next i

    End Sub
End Class