﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Exercise3_Tumala_Pauline
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lstParts = New System.Windows.Forms.ListBox()
        Me.cboDisc = New System.Windows.Forms.ComboBox()
        Me.Price = New System.Windows.Forms.Label()
        Me.Quantity = New System.Windows.Forms.Label()
        Me.SubTotal = New System.Windows.Forms.Label()
        Me.Discount = New System.Windows.Forms.Label()
        Me.TotalAmount = New System.Windows.Forms.Label()
        Me.txtUPrice = New System.Windows.Forms.TextBox()
        Me.txtSubTot = New System.Windows.Forms.TextBox()
        Me.txtDisc = New System.Windows.Forms.TextBox()
        Me.txtTotAmt = New System.Windows.Forms.TextBox()
        Me.nudQuan = New System.Windows.Forms.NumericUpDown()
        Me.btnCompute = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.nudQuan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lstParts)
        Me.GroupBox1.Location = New System.Drawing.Point(31, 37)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(197, 167)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Computer Parts"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.cboDisc)
        Me.GroupBox2.Location = New System.Drawing.Point(28, 229)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(200, 122)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Discount Rate"
        '
        'lstParts
        '
        Me.lstParts.FormattingEnabled = True
        Me.lstParts.Items.AddRange(New Object() {"Monitor", "Keyboard", "Mouse", "Hard Disk", "Disk Drive"})
        Me.lstParts.Location = New System.Drawing.Point(40, 45)
        Me.lstParts.Name = "lstParts"
        Me.lstParts.Size = New System.Drawing.Size(120, 82)
        Me.lstParts.TabIndex = 2
        '
        'cboDisc
        '
        Me.cboDisc.FormattingEnabled = True
        Me.cboDisc.Items.AddRange(New Object() {"5%", "10%", "15%", "& No"})
        Me.cboDisc.Location = New System.Drawing.Point(32, 54)
        Me.cboDisc.Name = "cboDisc"
        Me.cboDisc.Size = New System.Drawing.Size(121, 21)
        Me.cboDisc.TabIndex = 2
        Me.cboDisc.Text = "No Discount"
        '
        'Price
        '
        Me.Price.AutoSize = True
        Me.Price.Location = New System.Drawing.Point(299, 50)
        Me.Price.Name = "Price"
        Me.Price.Size = New System.Drawing.Size(53, 13)
        Me.Price.TabIndex = 2
        Me.Price.Text = "Unit Price"
        '
        'Quantity
        '
        Me.Quantity.AutoSize = True
        Me.Quantity.Location = New System.Drawing.Point(299, 97)
        Me.Quantity.Name = "Quantity"
        Me.Quantity.Size = New System.Drawing.Size(46, 13)
        Me.Quantity.TabIndex = 3
        Me.Quantity.Text = "Quantity"
        '
        'SubTotal
        '
        Me.SubTotal.AutoSize = True
        Me.SubTotal.Location = New System.Drawing.Point(299, 151)
        Me.SubTotal.Name = "SubTotal"
        Me.SubTotal.Size = New System.Drawing.Size(53, 13)
        Me.SubTotal.TabIndex = 4
        Me.SubTotal.Text = "Sub-Total"
        '
        'Discount
        '
        Me.Discount.AutoSize = True
        Me.Discount.Location = New System.Drawing.Point(299, 202)
        Me.Discount.Name = "Discount"
        Me.Discount.Size = New System.Drawing.Size(49, 13)
        Me.Discount.TabIndex = 5
        Me.Discount.Text = "Discount"
        '
        'TotalAmount
        '
        Me.TotalAmount.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.TotalAmount.AutoSize = True
        Me.TotalAmount.Location = New System.Drawing.Point(299, 254)
        Me.TotalAmount.Name = "TotalAmount"
        Me.TotalAmount.Size = New System.Drawing.Size(70, 13)
        Me.TotalAmount.TabIndex = 6
        Me.TotalAmount.Text = "Total Amount"
        Me.TotalAmount.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtUPrice
        '
        Me.txtUPrice.Location = New System.Drawing.Point(416, 50)
        Me.txtUPrice.Name = "txtUPrice"
        Me.txtUPrice.Size = New System.Drawing.Size(100, 20)
        Me.txtUPrice.TabIndex = 7
        '
        'txtSubTot
        '
        Me.txtSubTot.Location = New System.Drawing.Point(416, 151)
        Me.txtSubTot.Name = "txtSubTot"
        Me.txtSubTot.Size = New System.Drawing.Size(100, 20)
        Me.txtSubTot.TabIndex = 8
        '
        'txtDisc
        '
        Me.txtDisc.Location = New System.Drawing.Point(416, 195)
        Me.txtDisc.Name = "txtDisc"
        Me.txtDisc.Size = New System.Drawing.Size(100, 20)
        Me.txtDisc.TabIndex = 9
        '
        'txtTotAmt
        '
        Me.txtTotAmt.Location = New System.Drawing.Point(416, 251)
        Me.txtTotAmt.Name = "txtTotAmt"
        Me.txtTotAmt.Size = New System.Drawing.Size(100, 20)
        Me.txtTotAmt.TabIndex = 10
        '
        'nudQuan
        '
        Me.nudQuan.Location = New System.Drawing.Point(416, 95)
        Me.nudQuan.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudQuan.Name = "nudQuan"
        Me.nudQuan.Size = New System.Drawing.Size(68, 20)
        Me.nudQuan.TabIndex = 11
        Me.nudQuan.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'btnCompute
        '
        Me.btnCompute.Location = New System.Drawing.Point(247, 314)
        Me.btnCompute.Name = "btnCompute"
        Me.btnCompute.Size = New System.Drawing.Size(75, 23)
        Me.btnCompute.TabIndex = 12
        Me.btnCompute.Text = "Compute"
        Me.btnCompute.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(352, 314)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 13
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(454, 314)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 14
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Exercise3_Tumala_Pauline
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(559, 408)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCompute)
        Me.Controls.Add(Me.nudQuan)
        Me.Controls.Add(Me.txtTotAmt)
        Me.Controls.Add(Me.txtDisc)
        Me.Controls.Add(Me.txtSubTot)
        Me.Controls.Add(Me.txtUPrice)
        Me.Controls.Add(Me.TotalAmount)
        Me.Controls.Add(Me.Discount)
        Me.Controls.Add(Me.SubTotal)
        Me.Controls.Add(Me.Quantity)
        Me.Controls.Add(Me.Price)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Exercise3_Tumala_Pauline"
        Me.Text = "ComboBox, ListBox & Numeric UpDown"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.nudQuan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lstParts As System.Windows.Forms.ListBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents cboDisc As System.Windows.Forms.ComboBox
    Friend WithEvents Price As System.Windows.Forms.Label
    Friend WithEvents Quantity As System.Windows.Forms.Label
    Friend WithEvents SubTotal As System.Windows.Forms.Label
    Friend WithEvents Discount As System.Windows.Forms.Label
    Friend WithEvents TotalAmount As System.Windows.Forms.Label
    Friend WithEvents txtUPrice As System.Windows.Forms.TextBox
    Friend WithEvents txtSubTot As System.Windows.Forms.TextBox
    Friend WithEvents txtDisc As System.Windows.Forms.TextBox
    Friend WithEvents txtTotAmt As System.Windows.Forms.TextBox
    Friend WithEvents nudQuan As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnCompute As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
End Class
