﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Exercise7_TumalaPauline
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnShow = New System.Windows.Forms.Button()
        Me.btnHide = New System.Windows.Forms.Button()
        Me.btnEnable = New System.Windows.Forms.Button()
        Me.btnDisable = New System.Windows.Forms.Button()
        Me.picBaby = New System.Windows.Forms.PictureBox()
        CType(Me.picBaby, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnShow
        '
        Me.btnShow.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnShow.Font = New System.Drawing.Font("Chicken Quiche", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShow.Location = New System.Drawing.Point(174, 303)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(91, 43)
        Me.btnShow.TabIndex = 1
        Me.btnShow.Text = "SHOW"
        Me.btnShow.UseVisualStyleBackColor = False
        '
        'btnHide
        '
        Me.btnHide.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnHide.Font = New System.Drawing.Font("Chicken Quiche", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHide.Location = New System.Drawing.Point(316, 303)
        Me.btnHide.Name = "btnHide"
        Me.btnHide.Size = New System.Drawing.Size(75, 43)
        Me.btnHide.TabIndex = 2
        Me.btnHide.Text = "HIDE"
        Me.btnHide.UseVisualStyleBackColor = False
        '
        'btnEnable
        '
        Me.btnEnable.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnEnable.Font = New System.Drawing.Font("Chicken Quiche", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnable.Location = New System.Drawing.Point(138, 361)
        Me.btnEnable.Name = "btnEnable"
        Me.btnEnable.Size = New System.Drawing.Size(127, 36)
        Me.btnEnable.TabIndex = 3
        Me.btnEnable.Text = "ENABLE"
        Me.btnEnable.UseVisualStyleBackColor = False
        '
        'btnDisable
        '
        Me.btnDisable.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnDisable.Font = New System.Drawing.Font("Chicken Quiche", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisable.Location = New System.Drawing.Point(316, 361)
        Me.btnDisable.Name = "btnDisable"
        Me.btnDisable.Size = New System.Drawing.Size(114, 36)
        Me.btnDisable.TabIndex = 4
        Me.btnDisable.Text = "DISABLE"
        Me.btnDisable.UseVisualStyleBackColor = False
        '
        'picBaby
        '
        Me.picBaby.Image = Global.PRACTICE_EXERCISES.My.Resources.Resources.picBaby1
        Me.picBaby.Location = New System.Drawing.Point(146, 23)
        Me.picBaby.Margin = New System.Windows.Forms.Padding(1)
        Me.picBaby.Name = "picBaby"
        Me.picBaby.Size = New System.Drawing.Size(277, 265)
        Me.picBaby.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBaby.TabIndex = 0
        Me.picBaby.TabStop = False
        '
        'Exercise7_TumalaPauline
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(545, 449)
        Me.Controls.Add(Me.btnDisable)
        Me.Controls.Add(Me.btnEnable)
        Me.Controls.Add(Me.btnHide)
        Me.Controls.Add(Me.btnShow)
        Me.Controls.Add(Me.picBaby)
        Me.Name = "Exercise7_TumalaPauline"
        Me.Text = "PictureBox_Control"
        CType(Me.picBaby, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents picBaby As System.Windows.Forms.PictureBox
    Friend WithEvents btnShow As System.Windows.Forms.Button
    Friend WithEvents btnHide As System.Windows.Forms.Button
    Friend WithEvents btnEnable As System.Windows.Forms.Button
    Friend WithEvents btnDisable As System.Windows.Forms.Button
End Class
