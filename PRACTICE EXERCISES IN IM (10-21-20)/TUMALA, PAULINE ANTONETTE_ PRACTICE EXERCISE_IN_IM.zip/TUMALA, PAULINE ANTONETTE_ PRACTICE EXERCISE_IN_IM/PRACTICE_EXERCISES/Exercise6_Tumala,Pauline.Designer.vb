﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Exercise6_Tumala_Pauline
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnIn = New System.Windows.Forms.Button()
        Me.btnOut = New System.Windows.Forms.Button()
        Me.btnCompute1 = New System.Windows.Forms.Button()
        Me.btnCompute2 = New System.Windows.Forms.Button()
        Me.txtIn = New System.Windows.Forms.TextBox()
        Me.txtOut = New System.Windows.Forms.TextBox()
        Me.lblTotDays = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dtpIn = New System.Windows.Forms.DateTimePicker()
        Me.dtpOut = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnIn
        '
        Me.btnIn.Location = New System.Drawing.Point(68, 93)
        Me.btnIn.Name = "btnIn"
        Me.btnIn.Size = New System.Drawing.Size(79, 23)
        Me.btnIn.TabIndex = 0
        Me.btnIn.Text = "CHECK IN"
        Me.btnIn.UseVisualStyleBackColor = True
        '
        'btnOut
        '
        Me.btnOut.Location = New System.Drawing.Point(68, 143)
        Me.btnOut.Name = "btnOut"
        Me.btnOut.Size = New System.Drawing.Size(79, 23)
        Me.btnOut.TabIndex = 1
        Me.btnOut.Text = "CHECK OUT"
        Me.btnOut.UseVisualStyleBackColor = True
        '
        'btnCompute1
        '
        Me.btnCompute1.Location = New System.Drawing.Point(68, 216)
        Me.btnCompute1.Name = "btnCompute1"
        Me.btnCompute1.Size = New System.Drawing.Size(79, 23)
        Me.btnCompute1.TabIndex = 2
        Me.btnCompute1.Text = "COMPUTE 1"
        Me.btnCompute1.UseVisualStyleBackColor = True
        '
        'btnCompute2
        '
        Me.btnCompute2.Location = New System.Drawing.Point(346, 221)
        Me.btnCompute2.Name = "btnCompute2"
        Me.btnCompute2.Size = New System.Drawing.Size(79, 23)
        Me.btnCompute2.TabIndex = 3
        Me.btnCompute2.Text = "COMPUTE 2"
        Me.btnCompute2.UseVisualStyleBackColor = True
        '
        'txtIn
        '
        Me.txtIn.Location = New System.Drawing.Point(167, 95)
        Me.txtIn.Name = "txtIn"
        Me.txtIn.Size = New System.Drawing.Size(100, 20)
        Me.txtIn.TabIndex = 4
        '
        'txtOut
        '
        Me.txtOut.Location = New System.Drawing.Point(167, 145)
        Me.txtOut.Name = "txtOut"
        Me.txtOut.Size = New System.Drawing.Size(100, 20)
        Me.txtOut.TabIndex = 5
        '
        'lblTotDays
        '
        Me.lblTotDays.AutoSize = True
        Me.lblTotDays.Location = New System.Drawing.Point(191, 221)
        Me.lblTotDays.Name = "lblTotDays"
        Me.lblTotDays.Size = New System.Drawing.Size(0, 13)
        Me.lblTotDays.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(191, 190)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Total Days"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtpOut)
        Me.GroupBox1.Controls.Add(Me.dtpIn)
        Me.GroupBox1.Location = New System.Drawing.Point(293, 84)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(232, 126)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'dtpIn
        '
        Me.dtpIn.Location = New System.Drawing.Point(16, 38)
        Me.dtpIn.Name = "dtpIn"
        Me.dtpIn.Size = New System.Drawing.Size(200, 20)
        Me.dtpIn.TabIndex = 0
        '
        'dtpOut
        '
        Me.dtpOut.Location = New System.Drawing.Point(16, 79)
        Me.dtpOut.Name = "dtpOut"
        Me.dtpOut.Size = New System.Drawing.Size(200, 20)
        Me.dtpOut.TabIndex = 1
        '
        'Exercise6_Tumala_Pauline
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(575, 425)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblTotDays)
        Me.Controls.Add(Me.txtOut)
        Me.Controls.Add(Me.txtIn)
        Me.Controls.Add(Me.btnCompute2)
        Me.Controls.Add(Me.btnCompute1)
        Me.Controls.Add(Me.btnOut)
        Me.Controls.Add(Me.btnIn)
        Me.Name = "Exercise6_Tumala_Pauline"
        Me.Text = "Usign DateTimePicker &DateDiff Function"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnIn As System.Windows.Forms.Button
    Friend WithEvents btnOut As System.Windows.Forms.Button
    Friend WithEvents btnCompute1 As System.Windows.Forms.Button
    Friend WithEvents btnCompute2 As System.Windows.Forms.Button
    Friend WithEvents txtIn As System.Windows.Forms.TextBox
    Friend WithEvents txtOut As System.Windows.Forms.TextBox
    Friend WithEvents lblTotDays As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dtpOut As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpIn As System.Windows.Forms.DateTimePicker
End Class
