﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Sample_Password
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnE = New System.Windows.Forms.Button()
        Me.btnCl = New System.Windows.Forms.Button()
        Me.btnC = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txt1
        '
        Me.txt1.Location = New System.Drawing.Point(209, 9)
        Me.txt1.Multiline = True
        Me.txt1.Name = "txt1"
        Me.txt1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt1.Size = New System.Drawing.Size(131, 32)
        Me.txt1.TabIndex = 14
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(140, 32)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Enter Password"
        '
        'btnE
        '
        Me.btnE.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnE.Location = New System.Drawing.Point(245, 78)
        Me.btnE.Name = "btnE"
        Me.btnE.Size = New System.Drawing.Size(95, 43)
        Me.btnE.TabIndex = 12
        Me.btnE.Text = "Exit"
        Me.btnE.UseVisualStyleBackColor = True
        '
        'btnCl
        '
        Me.btnCl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCl.Location = New System.Drawing.Point(123, 78)
        Me.btnCl.Name = "btnCl"
        Me.btnCl.Size = New System.Drawing.Size(95, 43)
        Me.btnCl.TabIndex = 11
        Me.btnCl.Text = "Clear"
        Me.btnCl.UseVisualStyleBackColor = True
        '
        'btnC
        '
        Me.btnC.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnC.Location = New System.Drawing.Point(4, 78)
        Me.btnC.Name = "btnC"
        Me.btnC.Size = New System.Drawing.Size(95, 43)
        Me.btnC.TabIndex = 10
        Me.btnC.Text = "ClickMe"
        Me.btnC.UseVisualStyleBackColor = True
        '
        'Sample_Password
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(373, 137)
        Me.Controls.Add(Me.txt1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnE)
        Me.Controls.Add(Me.btnCl)
        Me.Controls.Add(Me.btnC)
        Me.Name = "Sample_Password"
        Me.Text = "Sample_Password"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txt1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnE As System.Windows.Forms.Button
    Friend WithEvents btnCl As System.Windows.Forms.Button
    Friend WithEvents btnC As System.Windows.Forms.Button
End Class
