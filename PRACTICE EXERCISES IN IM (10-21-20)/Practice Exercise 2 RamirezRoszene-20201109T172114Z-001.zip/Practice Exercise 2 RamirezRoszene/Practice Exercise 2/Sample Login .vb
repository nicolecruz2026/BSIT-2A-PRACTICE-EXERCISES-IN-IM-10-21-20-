﻿Public Class Sample_Login

    Private Sub btnE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnE.Click
        Close()

    End Sub

    Private Sub btnCL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCL.Click
        txt1.Text = " "
        txt2.Text = " "
    End Sub

    Private Sub btnC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnC.Click

        Dim username As String = "Admin"
        Dim password As String = "Administrator"
        If username = txt1.Text And password = txt2.Text Then
            MessageBox.Show("Login Successful")
        Else
            MessageBox.Show("Incorrect Username and Password")
        End If
    End Sub
End Class