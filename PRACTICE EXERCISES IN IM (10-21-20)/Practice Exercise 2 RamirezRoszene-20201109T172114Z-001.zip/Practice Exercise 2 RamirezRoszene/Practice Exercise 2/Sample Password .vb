﻿Public Class Sample_Password

    Private Sub btnCl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCl.Click
        txt1.Text = " "
    End Sub

    Private Sub btnE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnE.Click
        Close()
    End Sub

    Private Sub btnC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnC.Click

        If txt1.Text = "Password" Then
            MessageBox.Show("Access Granted", "Password", MessageBoxButtons.OK,
            MessageBoxIcon.Information)
        Else
            MessageBox.Show("Access Denied", "Password", MessageBoxButtons.OK,
            MessageBoxIcon.Information)
        End If
    End Sub
End Class