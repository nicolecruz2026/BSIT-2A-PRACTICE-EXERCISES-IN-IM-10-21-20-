﻿Public Class Form1

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        txt1.Text = " "
        lblLetter.Text = " "
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click

        Dim choice As Char
        choice = LCase(txt1.Text)
        Select Case choice
            Case "r"
                lblLetter.Text = "Red"
                lblLetter.ForeColor = Color.Red
            Case "b"
                lblLetter.Text = "Blue"
                lblLetter.ForeColor = Color.Blue
            Case "y"
                lblLetter.Text = "Yellow"
                lblLetter.ForeColor = Color.Yellow
            Case "g"
                lblLetter.Text = "Green"
                lblLetter.ForeColor = Color.Green
            Case Else
                lblLetter.Text = "OUT OF RANGE"
        End Select
    End Sub
End Class
