﻿Public Class _2ListBox

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Dim i As Byte

        For i = 0 To ListBox1.Items.Count
            If ListBox1.SelectedIndex = i Then
                ListBox2.Items.Add(ListBox1.SelectedItem)
            End If
        Next

    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Dim i As Integer

        For i = 0 To ListBox1.Items.Count
            If ListBox2.SelectedIndex = i Then
                ListBox2.Items.RemoveAt(i)
            End If
        Next
    End Sub

    Private Sub btnClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearAll.Click
        ListBox1.ClearSelected()
        ListBox2.Items.Clear()
    End Sub
End Class