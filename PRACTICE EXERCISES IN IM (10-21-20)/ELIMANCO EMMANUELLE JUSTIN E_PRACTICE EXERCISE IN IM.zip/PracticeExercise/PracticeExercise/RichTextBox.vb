﻿Public Class RichTextBox

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Dim Means As String
        Dim i As Byte

        Select Case ListBox1.SelectedIndex
            Case 0
                Means = " - A small piece of message that is transported over the Internet."

            Case 1

                Means = " - A special-purpose computer that directs packets of data along a network."

            Case 2
                Means = " - A security mechanism that organizations use to protect their intranet from the Internet."

            Case 3
                Means = " - A program that allows you to log into a remote computer."

            Case 4
                Means = " - A set of precisely specified rules for carrying out a procedure."

        End Select
        For i = 0 To 4
            If ListBox1.SelectedIndex = i Then
                rchMeaning.Text = ListBox1.Items.Item(i) + Means
            End If
        Next
    End Sub
End Class