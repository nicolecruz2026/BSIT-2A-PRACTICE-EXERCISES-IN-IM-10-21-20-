﻿Public Class SampleArray

    Private Sub btnView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnView.Click
        Dim Names() As String = {"Richard", "Noli", "Lester", "Val"}
        Dim Scores() As Single = {100, 80, 70, 95}
        Dim i As Integer
        Dim Total As Single = 0

        For i = 0 To Names.Length - 1 'or => For i = 0 to 3
            ListBox1.Items.Add(Names(i))
            ListBox2.Items.Add(Scores(i))
            Total += (Scores(i))

        Next
        lblAve.Text = Total / Scores.Length
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        lblAve.Text = ""
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        End
    End Sub
End Class